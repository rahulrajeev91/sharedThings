var WebSocketServer = require('ws').Server, wss = new WebSocketServer({port: 8000});
var messages=[];

wss.on('close', function() {
    console.log('disconnected');
});

wss.broadcast = function(data) {
    for(var i in this.clients)
        this.clients[i].send(data);
};

wss.on('connection', function(ws) {
	for(var i=0;i<messages.length;i++){
		ws.send(messages[i]); // careful!
	}
	ws.on('message', function(message) {
		console.log('received: %s', message);
		messages.push(message);
		wss.broadcast(message);
		if(message=="delay"){
			console.log('delaying');
			while(1);
		}
	});
});
